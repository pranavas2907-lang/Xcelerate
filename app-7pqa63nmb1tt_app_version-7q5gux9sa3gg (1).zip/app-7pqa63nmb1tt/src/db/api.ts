import { supabase } from './supabase';
import type {
  StudentProfile,
  TeacherAvatar,
  LearningProgress,
  TestResult,
  StudentGoal,
  Achievement,
} from '@/types';

export const db = {
  studentProfiles: {
    async getById(id: string) {
      const { data, error } = await supabase
        .from('student_profiles')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async create(profile: Omit<StudentProfile, 'id' | 'created_at' | 'updated_at'>) {
      const { data, error } = await supabase
        .from('student_profiles')
        .insert(profile)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async update(id: string, updates: Partial<StudentProfile>) {
      const { data, error } = await supabase
        .from('student_profiles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  },

  teacherAvatars: {
    async getByStudentId(studentId: string) {
      const { data, error } = await supabase
        .from('teacher_avatars')
        .select('*')
        .eq('student_id', studentId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async getActive(studentId: string) {
      const { data, error } = await supabase
        .from('teacher_avatars')
        .select('*')
        .eq('student_id', studentId)
        .eq('is_active', true)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async create(avatar: Omit<TeacherAvatar, 'id' | 'created_at'>) {
      const { data, error } = await supabase
        .from('teacher_avatars')
        .insert(avatar)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async setActive(id: string, studentId: string) {
      await supabase
        .from('teacher_avatars')
        .update({ is_active: false })
        .eq('student_id', studentId);

      const { data, error } = await supabase
        .from('teacher_avatars')
        .update({ is_active: true })
        .eq('id', id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async update(id: string, updates: Partial<TeacherAvatar>) {
      const { data, error } = await supabase
        .from('teacher_avatars')
        .update(updates)
        .eq('id', id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async delete(id: string) {
      const { error } = await supabase
        .from('teacher_avatars')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
  },

  learningProgress: {
    async getByStudentId(studentId: string) {
      const { data, error } = await supabase
        .from('learning_progress')
        .select('*')
        .eq('student_id', studentId)
        .order('last_accessed', { ascending: false });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async getBySubject(studentId: string, subject: string) {
      const { data, error } = await supabase
        .from('learning_progress')
        .select('*')
        .eq('student_id', studentId)
        .eq('subject', subject)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async upsert(progress: Omit<LearningProgress, 'id' | 'created_at'>) {
      const { data, error } = await supabase
        .from('learning_progress')
        .upsert(progress, { onConflict: 'student_id,subject,topic' })
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async updateTimeSpent(studentId: string, subject: string, topic: string, additionalMinutes: number) {
      const existing = await supabase
        .from('learning_progress')
        .select('time_spent_minutes')
        .eq('student_id', studentId)
        .eq('subject', subject)
        .eq('topic', topic)
        .maybeSingle();

      const currentTime = existing.data?.time_spent_minutes || 0;

      const { data, error } = await supabase
        .from('learning_progress')
        .upsert({
          student_id: studentId,
          subject,
          topic,
          time_spent_minutes: currentTime + additionalMinutes,
          last_accessed: new Date().toISOString(),
        }, { onConflict: 'student_id,subject,topic' })
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  },

  testResults: {
    async getByStudentId(studentId: string) {
      const { data, error } = await supabase
        .from('test_results')
        .select('*')
        .eq('student_id', studentId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async getBySubject(studentId: string, subject: string) {
      const { data, error } = await supabase
        .from('test_results')
        .select('*')
        .eq('student_id', studentId)
        .eq('subject', subject)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async create(result: Omit<TestResult, 'id' | 'created_at'>) {
      const { data, error } = await supabase
        .from('test_results')
        .insert(result)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  },

  studentGoals: {
    async getByStudentId(studentId: string) {
      const { data, error } = await supabase
        .from('student_goals')
        .select('*')
        .eq('student_id', studentId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async create(goal: Omit<StudentGoal, 'id' | 'created_at'>) {
      const { data, error } = await supabase
        .from('student_goals')
        .insert(goal)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async updateProgress(id: string, currentValue: number) {
      const { data, error } = await supabase
        .from('student_goals')
        .update({ current_value: currentValue })
        .eq('id', id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },

    async complete(id: string) {
      const { data, error } = await supabase
        .from('student_goals')
        .update({ 
          completed: true, 
          completed_at: new Date().toISOString() 
        })
        .eq('id', id)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  },

  achievements: {
    async getByStudentId(studentId: string) {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .eq('student_id', studentId)
        .order('earned_at', { ascending: false });
      
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },

    async create(achievement: Omit<Achievement, 'id' | 'earned_at'>) {
      const { data, error } = await supabase
        .from('achievements')
        .insert(achievement)
        .select()
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  },
};
