import { useLanguage } from '@/contexts/LanguageContext';
import { Link } from 'react-router-dom';
import { BookOpen, Brain, Globe, Sparkles } from 'lucide-react';

export default function Footer() {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-card">
      <div className="container mx-auto py-16 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Brain className="h-5 w-5" />
              {t('aboutUs')}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Shiksha AI is an immersive, AI-powered educational platform designed for Indian students
              to learn core subjects through personalized AI teachers with Indian cultural context.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              {t('subjects')}
            </h3>
            <div className="space-y-2">
              <Link to="/subjects/mathematics" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                {t('mathematics')}
              </Link>
              <Link to="/subjects/science" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                {t('science')}
              </Link>
              <Link to="/subjects/history" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                {t('history')}
              </Link>
              <Link to="/subjects/geography" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                {t('geography')}
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              Features
            </h3>
            <div className="space-y-2">
              <Link to="/teacher" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                AI Teacher Customization
              </Link>
              <Link to="/dashboard" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                Progress Tracking
              </Link>
              <Link to="/settings" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                Multi-Language Support
              </Link>
              <Link to="/my-teachers" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                My Teachers
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
              <Globe className="h-5 w-5" />
              Resources
            </h3>
            <div className="space-y-2">
              <Link to="/help" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                Getting Started
              </Link>
              <Link to="/faq" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                FAQ
              </Link>
              <Link to="/support" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                Support
              </Link>
              <Link to="/privacy" className="block text-sm text-muted-foreground hover:text-primary transition-smooth">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            {currentYear} Shiksha AI
          </p>
        </div>
      </div>
    </footer>
  );
}
