import type { Language } from '@/types';

const languageVoiceMap: Record<Language, string> = {
  en: 'en-IN',
  hi: 'hi-IN',
  kn: 'kn-IN',
  ta: 'ta-IN',
  te: 'te-IN',
  ml: 'ml-IN',
  mr: 'mr-IN',
};

function cleanTextForSpeech(text: string): string {
  let cleaned = text;

  cleaned = cleaned.replace(/[#*_`~]/g, '');
  cleaned = cleaned.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  cleaned = cleaned.replace(/!\[([^\]]*)\]\([^)]+\)/g, '');
  cleaned = cleaned.replace(/^[-*+]\s+/gm, '');
  cleaned = cleaned.replace(/^\d+\.\s+/gm, '');
  cleaned = cleaned.replace(/```[\s\S]*?```/g, '');
  cleaned = cleaned.replace(/`([^`]+)`/g, '$1');
  cleaned = cleaned.replace(/[<>{}[\]]/g, '');
  cleaned = cleaned.replace(/\s+/g, ' ');
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
  cleaned = cleaned.trim();

  return cleaned;
}

export class TTSService {
  private synthesis: SpeechSynthesis;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isPaused = false;

  constructor() {
    this.synthesis = window.speechSynthesis;
  }

  speak(text: string, language: Language = 'en', rate = 1.0): void {
    this.stop();

    if (!text || text.trim().length === 0) {
      console.error('TTS Error: No text to speak.');
      return;
    }

    const cleanedText = cleanTextForSpeech(text);

    if (cleanedText.length === 0) {
      console.error('TTS Error: Text is empty after cleaning.');
      return;
    }

    this.currentUtterance = new SpeechSynthesisUtterance(cleanedText);
    this.currentUtterance.lang = languageVoiceMap[language];
    this.currentUtterance.rate = Math.max(0.5, Math.min(2.0, rate));
    this.currentUtterance.pitch = 1;
    this.currentUtterance.volume = 1;

    this.currentUtterance.onerror = (event) => {
      console.error('TTS Error:', event.error);
    };

    this.currentUtterance.onend = () => {
      this.isPaused = false;
    };

    this.synthesis.speak(this.currentUtterance);
    this.isPaused = false;
  }

  pause(): void {
    if (this.synthesis.speaking && !this.isPaused) {
      this.synthesis.pause();
      this.isPaused = true;
    }
  }

  resume(): void {
    if (this.isPaused) {
      this.synthesis.resume();
      this.isPaused = false;
    }
  }

  stop(): void {
    this.synthesis.cancel();
    this.currentUtterance = null;
    this.isPaused = false;
  }

  isSpeaking(): boolean {
    return this.synthesis.speaking;
  }

  isPausedState(): boolean {
    return this.isPaused;
  }
}

export const ttsService = new TTSService();
