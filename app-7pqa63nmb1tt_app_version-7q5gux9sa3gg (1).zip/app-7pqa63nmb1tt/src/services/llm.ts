const APP_ID = import.meta.env.VITE_APP_ID || 'app-7pqa63nmb1tt';
const LLM_API_URL = `https://api-integrations.appmedo.com/${APP_ID}/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse`;

export interface LLMMessage {
  role: 'user' | 'model';
  parts: Array<{
    text?: string;
    inlineData?: {
      mimeType: string;
      data: string;
    };
  }>;
}

export interface LLMResponse {
  candidates: Array<{
    content: {
      role: string;
      parts: Array<{
        text: string;
      }>;
    };
    finishReason: string;
  }>;
}

export async function sendLLMMessage(
  messages: LLMMessage[],
  onChunk?: (text: string) => void
): Promise<string> {
  try {
    const response = await fetch(LLM_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-App-Id': APP_ID,
      },
      body: JSON.stringify({
        contents: messages,
      }),
    });

    if (!response.ok) {
      throw new Error(`LLM API error: ${response.statusText}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    if (!reader) {
      throw new Error('No response body');
    }

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const jsonData = JSON.parse(line.slice(6));
            const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
            if (text) {
              fullText += text;
              if (onChunk) {
                onChunk(text);
              }
            }
          } catch (e) {
            console.error('Error parsing SSE data:', e);
          }
        }
      }
    }

    return fullText;
  } catch (error) {
    console.error('LLM API Error:', error);
    throw error;
  }
}

export async function generateAIResponse(
  userMessage: string,
  context?: string,
  conversationHistory?: LLMMessage[]
): Promise<string> {
  const messages: LLMMessage[] = conversationHistory || [];
  
  if (context && messages.length === 0) {
    messages.push({
      role: 'model',
      parts: [{ text: context }],
    });
  }

  messages.push({
    role: 'user',
    parts: [{ text: userMessage }],
  });

  return sendLLMMessage(messages);
}
