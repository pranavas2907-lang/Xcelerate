// Audio Service for Multi-Language Support
// Uses Web Audio API for playing language-specific audio files

interface AudioTrack {
  language: string;
  url: string;
  audio: HTMLAudioElement | null;
}

class AudioService {
  private tracks: Map<string, AudioTrack> = new Map();
  private currentAudio: HTMLAudioElement | null = null;

  constructor() {
    // Initialize audio tracks for different languages
    this.initializeTracks();
  }

  private initializeTracks() {
    const languages = [
      { code: 'en', name: 'English' },
      { code: 'hi', name: 'Hindi' },
      { code: 'kn', name: 'Kannada' },
      { code: 'ta', name: 'Tamil' },
      { code: 'te', name: 'Telugu' },
      { code: 'ml', name: 'Malayalam' },
      { code: 'mr', name: 'Marathi' },
    ];

    languages.forEach(lang => {
      this.tracks.set(lang.code, {
        language: lang.name,
        url: `/audio/${lang.code}.mp3`,
        audio: null,
      });
    });
  }

  // Play audio for a specific language
  playLanguage(languageCode: string): Promise<void> {
    return new Promise((resolve, reject) => {
      // Stop current audio if playing
      this.stop();

      const track = this.tracks.get(languageCode);
      if (!track) {
        reject(new Error(`Language ${languageCode} not found`));
        return;
      }

      // Create audio element if not exists
      if (!track.audio) {
        track.audio = new Audio(track.url);
        track.audio.preload = 'auto';
      }

      this.currentAudio = track.audio;

      // Play audio
      this.currentAudio.play()
        .then(() => {
          console.log(`Playing ${track.language} audio`);
          resolve();
        })
        .catch((error) => {
          console.error(`Error playing ${track.language} audio:`, error);
          reject(error);
        });

      // Handle audio end
      this.currentAudio.onended = () => {
        console.log(`${track.language} audio finished`);
        this.currentAudio = null;
      };
    });
  }

  // Stop current audio
  stop() {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
  }

  // Pause current audio
  pause() {
    if (this.currentAudio) {
      this.currentAudio.pause();
    }
  }

  // Resume current audio
  resume() {
    if (this.currentAudio) {
      this.currentAudio.play().catch(error => {
        console.error('Error resuming audio:', error);
      });
    }
  }

  // Set volume (0-1)
  setVolume(volume: number) {
    if (this.currentAudio) {
      this.currentAudio.volume = Math.max(0, Math.min(1, volume));
    }
  }

  // Check if audio is playing
  isPlaying(): boolean {
    return this.currentAudio !== null && !this.currentAudio.paused;
  }

  // Preload audio for a language
  preload(languageCode: string) {
    const track = this.tracks.get(languageCode);
    if (track && !track.audio) {
      track.audio = new Audio(track.url);
      track.audio.preload = 'auto';
    }
  }

  // Preload all audio tracks
  preloadAll() {
    this.tracks.forEach((track, code) => {
      this.preload(code);
    });
  }
}

// Export singleton instance
export const audioService = new AudioService();

// Example usage:
// audioService.playLanguage('en'); // Play English
// audioService.playLanguage('hi'); // Play Hindi
// audioService.playLanguage('kn'); // Play Kannada
// audioService.stop(); // Stop current audio
// audioService.pause(); // Pause current audio
// audioService.resume(); // Resume current audio
// audioService.setVolume(0.5); // Set volume to 50%
