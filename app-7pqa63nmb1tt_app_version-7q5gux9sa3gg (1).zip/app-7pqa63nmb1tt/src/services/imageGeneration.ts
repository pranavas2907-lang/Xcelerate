const APP_ID = import.meta.env.VITE_APP_ID || 'app-7pqa63nmb1tt';
const IMAGE_GEN_API_URL = `https://api-integrations.appmedo.com/${APP_ID}/api-Xa6JZ58oPMEa/v1beta/models/gemini-3-pro-image-preview:generateContent`;

export interface ImageGenerationRequest {
  prompt: string;
  baseImage?: string;
  additionalImages?: string[];
}

export interface ImageGenerationResponse {
  status: number;
  msg: string;
  candidates: Array<{
    content: {
      role: string;
      parts: Array<{
        text: string;
      }>;
    };
    finishReason: string;
    safetyRatings: unknown[];
  }>;
}

export async function generateImage(request: ImageGenerationRequest): Promise<string> {
  try {
    const parts: Array<{ text?: string; inline_data?: { mime_type: string; data: string } }> = [];

    if (request.baseImage) {
      parts.push({
        inline_data: {
          mime_type: 'image/png',
          data: request.baseImage.split(',')[1] || request.baseImage,
        },
      });
    }

    if (request.additionalImages) {
      for (const img of request.additionalImages) {
        parts.push({
          inline_data: {
            mime_type: 'image/png',
            data: img.split(',')[1] || img,
          },
        });
      }
    }

    parts.push({
      text: request.prompt,
    });

    const response = await fetch(IMAGE_GEN_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-App-Id': APP_ID,
      },
      body: JSON.stringify({
        contents: [
          {
            parts,
          },
        ],
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      if (errorData.status === 999) {
        throw new Error(errorData.msg);
      }
      throw new Error(`Image generation failed: ${response.statusText}`);
    }

    const data: ImageGenerationResponse = await response.json();

    if (data.status !== 0) {
      throw new Error(data.msg || 'Image generation failed');
    }

    const imageText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!imageText) {
      throw new Error('No image generated');
    }

    const imageMatch = imageText.match(/!\[image\]\((data:image\/[^)]+)\)/);
    if (!imageMatch) {
      throw new Error('Failed to extract image from response');
    }

    return imageMatch[1];
  } catch (error) {
    console.error('Image Generation Error:', error);
    throw error;
  }
}

export async function generateTeacherAvatar(
  faceImageBase64: string,
  attireStyle: string,
  background: string,
  accessories: string[]
): Promise<string> {
  const prompt = `Create a professional 3D avatar of a teacher with the following specifications:
- Use the provided face image as the base
- Dress the avatar in ${attireStyle}
- Place the avatar in a ${background} setting
- Add these accessories: ${accessories.join(', ')}
- Make it look realistic and professional
- The avatar should have a friendly, welcoming expression
- High quality, detailed rendering`;

  return generateImage({
    prompt,
    baseImage: faceImageBase64,
  });
}
