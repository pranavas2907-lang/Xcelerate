import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { StudentProfile } from '@/types';
import { db } from '@/db/api';

interface StudentContextType {
  student: StudentProfile | null;
  studentId: string;
  loading: boolean;
  updateStudent: (updates: Partial<StudentProfile>) => Promise<void>;
  initializeStudent: (name: string, grade?: string) => Promise<void>;
}

const StudentContext = createContext<StudentContextType | undefined>(undefined);

export function StudentProvider({ children }: { children: ReactNode }) {
  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [studentId, setStudentId] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    initializeStudentId();
  }, []);

  const initializeStudentId = async () => {
    try {
      let id = localStorage.getItem('studentId');
      
      if (!id) {
        id = crypto.randomUUID();
        localStorage.setItem('studentId', id);
      }

      setStudentId(id);

      const existingStudent = await db.studentProfiles.getById(id);
      
      if (existingStudent) {
        setStudent(existingStudent);
      }
    } catch (error) {
      console.error('Error initializing student:', error);
    } finally {
      setLoading(false);
    }
  };

  const initializeStudent = async (name: string, grade?: string) => {
    try {
      const newStudent = await db.studentProfiles.create({
        name,
        grade,
        preferred_ui_language: 'en',
        preferred_content_language: 'en',
      });

      if (newStudent) {
        setStudent(newStudent);
        setStudentId(newStudent.id);
        localStorage.setItem('studentId', newStudent.id);
      }
    } catch (error) {
      console.error('Error creating student profile:', error);
      throw error;
    }
  };

  const updateStudent = async (updates: Partial<StudentProfile>) => {
    if (!studentId) return;

    try {
      const updated = await db.studentProfiles.update(studentId, updates);
      if (updated) {
        setStudent(updated);
      }
    } catch (error) {
      console.error('Error updating student profile:', error);
      throw error;
    }
  };

  return (
    <StudentContext.Provider
      value={{
        student,
        studentId,
        loading,
        updateStudent,
        initializeStudent,
      }}
    >
      {children}
    </StudentContext.Provider>
  );
}

export function useStudent() {
  const context = useContext(StudentContext);
  if (!context) {
    throw new Error('useStudent must be used within a StudentProvider');
  }
  return context;
}
