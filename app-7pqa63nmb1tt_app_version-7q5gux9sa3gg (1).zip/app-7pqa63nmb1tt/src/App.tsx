import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { StudentProvider } from '@/contexts/StudentContext';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import AIChatbot from '@/components/AIChatbot';
import routes from './routes';

export default function App() {
  return (
    <Router>
      <LanguageProvider>
        <StudentProvider>
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
              <Routes>
                {routes.map((route) => (
                  <Route key={route.path} path={route.path} element={route.element} />
                ))}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
            <Footer />
            <AIChatbot />
          </div>
          <Toaster />
        </StudentProvider>
      </LanguageProvider>
    </Router>
  );
}
