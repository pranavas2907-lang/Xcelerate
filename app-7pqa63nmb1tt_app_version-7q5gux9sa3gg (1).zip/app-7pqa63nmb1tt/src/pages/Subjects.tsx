import { Link } from 'react-router-dom';
import { BookOpen, Atom, History, Globe2, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Subjects() {
  const { t } = useLanguage();

  const subjects = [
    {
      id: 'mathematics',
      title: t('mathematics'),
      description: 'Master mathematical concepts from basics to advanced',
      icon: BookOpen,
      color: 'from-blue-500 to-cyan-500',
      topics: [
        { id: 'algebra', name: 'Algebra', lessons: 12 },
        { id: 'geometry', name: 'Geometry', lessons: 10 },
        { id: 'calculus', name: 'Calculus', lessons: 15 },
        { id: 'trigonometry', name: 'Trigonometry', lessons: 8 },
      ],
    },
    {
      id: 'physics',
      title: t('physics'),
      description: 'Explore the laws of nature and physical phenomena',
      icon: Atom,
      color: 'from-purple-500 to-pink-500',
      topics: [
        { id: 'optics', name: 'Optics', lessons: 8 },
        { id: 'motion', name: 'Laws of Motion', lessons: 10 },
        { id: 'equilibrium', name: 'Equilibrium', lessons: 6 },
        { id: 'modern-physics', name: 'Modern Physics', lessons: 12 },
      ],
    },
    {
      id: 'chemistry',
      title: t('chemistry'),
      description: 'Understand the composition and properties of matter',
      icon: Atom,
      color: 'from-green-500 to-emerald-500',
      topics: [
        { id: 'organic', name: 'Organic Chemistry', lessons: 15 },
        { id: 'inorganic', name: 'Inorganic Chemistry', lessons: 12 },
        { id: 'physical', name: 'Physical Chemistry', lessons: 10 },
      ],
    },
    {
      id: 'biology',
      title: t('biology'),
      description: 'Study living organisms and life processes',
      icon: Atom,
      color: 'from-teal-500 to-cyan-500',
      topics: [
        { id: 'cell', name: 'Cell Biology', lessons: 8 },
        { id: 'genetics', name: 'Genetics', lessons: 10 },
        { id: 'ecology', name: 'Ecology', lessons: 7 },
      ],
    },
    {
      id: 'history',
      title: t('history'),
      description: 'Journey through Indian history and culture',
      icon: History,
      color: 'from-amber-500 to-orange-500',
      topics: [
        { id: 'ramayana', name: 'Ramayana', lessons: 6 },
        { id: 'mahabharata', name: 'Mahabharata', lessons: 8 },
        { id: 'mughal', name: 'Mughal Empire', lessons: 10 },
        { id: 'gupta', name: 'Gupta Dynasty', lessons: 7 },
      ],
    },
    {
      id: 'geography',
      title: t('geography'),
      description: 'Explore Earth\'s features and natural resources',
      icon: Globe2,
      color: 'from-indigo-500 to-purple-500',
      topics: [
        { id: 'minerals', name: 'Minerals', lessons: 5 },
        { id: 'soil', name: 'Soil Formation', lessons: 6 },
        { id: 'rocks', name: 'Rock Formation', lessons: 5 },
        { id: 'amazon', name: 'Amazon Flora & Fauna', lessons: 8 },
      ],
    },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">{t('subjects')}</h1>
          <p className="text-lg text-muted-foreground max-w-3xl">
            Choose a subject to begin your learning journey. Each subject contains comprehensive lessons
            with AI-powered teaching and interactive content.
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {subjects.map((subject) => (
            <Card key={subject.id} className="transition-smooth hover:shadow-elegant">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${subject.color} flex items-center justify-center`}>
                      <subject.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl">{subject.title}</CardTitle>
                      <CardDescription className="mt-1">{subject.description}</CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {subject.topics.map((topic) => (
                    <Link
                      key={topic.id}
                      to={`/learn/${subject.id}/${topic.id}`}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-muted transition-smooth group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-primary" />
                        <span className="font-medium">{topic.name}</span>
                        <Badge variant="secondary" className="text-xs">
                          {topic.lessons} lessons
                        </Badge>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-smooth" />
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
