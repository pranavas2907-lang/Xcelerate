import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Trash2, Check } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { useStudent } from '@/contexts/StudentContext';
import { db } from '@/db/api';
import { toast } from 'sonner';
import type { TeacherAvatar } from '@/types';

export default function MyTeachers() {
  const { t } = useLanguage();
  const { studentId } = useStudent();
  const [teachers, setTeachers] = useState<TeacherAvatar[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTeachers();
  }, [studentId]);

  const loadTeachers = async () => {
    try {
      const data = await db.teacherAvatars.getByStudentId(studentId);
      setTeachers(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error loading teachers:', error);
      toast.error('Failed to load teacher avatars');
    } finally {
      setLoading(false);
    }
  };

  const handleSetActive = async (teacherId: string) => {
    try {
      await Promise.all(
        teachers.map((teacher) =>
          db.teacherAvatars.update(teacher.id, {
            is_active: teacher.id === teacherId,
          })
        )
      );

      setTeachers((prev) =>
        prev.map((teacher) => ({
          ...teacher,
          is_active: teacher.id === teacherId,
        }))
      );

      toast.success('Active teacher updated');
    } catch (error) {
      console.error('Error setting active teacher:', error);
      toast.error('Failed to update active teacher');
    }
  };

  const handleDelete = async (teacherId: string) => {
    if (!confirm('Are you sure you want to delete this teacher avatar?')) return;

    try {
      await db.teacherAvatars.delete(teacherId);
      setTeachers((prev) => prev.filter((t) => t.id !== teacherId));
      toast.success('Teacher avatar deleted');
    } catch (error) {
      console.error('Error deleting teacher:', error);
      toast.error('Failed to delete teacher avatar');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
          <p className="text-muted-foreground">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">My AI Teachers</h1>
            <p className="text-lg text-muted-foreground">
              Manage your customized AI teacher avatars
            </p>
          </div>
          <Button asChild size="lg">
            <Link to="/teacher">
              <Plus className="h-4 w-4 mr-2" />
              Create New Teacher
            </Link>
          </Button>
        </div>

        {teachers.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <div className="max-w-md mx-auto">
                <h3 className="text-xl font-semibold mb-2">No Teachers Yet</h3>
                <p className="text-muted-foreground mb-6">
                  Create your first AI teacher avatar to get started with personalized learning
                </p>
                <Button asChild>
                  <Link to="/teacher">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Your First Teacher
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {teachers.map((teacher) => (
              <Card key={teacher.id} className="overflow-hidden">
                <div className="relative">
                  <img
                    src={teacher.image_url}
                    alt={teacher.name}
                    className="w-full h-64 object-cover"
                  />
                  {teacher.is_active && (
                    <Badge className="absolute top-2 right-2">
                      <Check className="h-3 w-3 mr-1" />
                      Active
                    </Badge>
                  )}
                </div>
                <CardHeader>
                  <CardTitle>{teacher.name}</CardTitle>
                  <CardDescription>
                    <div className="space-y-1 text-xs">
                      <p>Attire: {teacher.attire_style}</p>
                      <p>Background: {teacher.background_type}</p>
                      {teacher.accessories && typeof teacher.accessories === 'object' && 'items' in teacher.accessories && (
                        <p>Accessories: {Array.isArray(teacher.accessories.items) ? teacher.accessories.items.join(', ') : 'None'}</p>
                      )}
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex gap-2">
                  {!teacher.is_active && (
                    <Button
                      onClick={() => handleSetActive(teacher.id)}
                      variant="default"
                      size="sm"
                      className="flex-1"
                    >
                      Set as Active
                    </Button>
                  )}
                  <Button
                    onClick={() => handleDelete(teacher.id)}
                    variant="destructive"
                    size="sm"
                    className={teacher.is_active ? 'flex-1' : ''}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
