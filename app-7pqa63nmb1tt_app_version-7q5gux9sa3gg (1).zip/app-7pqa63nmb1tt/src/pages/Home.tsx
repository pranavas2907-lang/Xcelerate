import { Link } from 'react-router-dom';
import { BookOpen, Brain, Globe2, TrendingUp, Sparkles, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Home() {
  const { t } = useLanguage();

  const subjects = [
    {
      title: t('mathematics'),
      description: 'Algebra, Geometry, Calculus, Trigonometry',
      icon: Brain,
      color: 'from-blue-500 to-cyan-500',
      path: '/subjects/mathematics',
    },
    {
      title: t('science'),
      description: 'Physics, Chemistry, Biology',
      icon: Sparkles,
      color: 'from-green-500 to-emerald-500',
      path: '/subjects/science',
    },
    {
      title: t('history'),
      description: 'Ramayana, Mahabharata, Mughal Empire',
      icon: BookOpen,
      color: 'from-amber-500 to-orange-500',
      path: '/subjects/history',
    },
    {
      title: t('geography'),
      description: 'Minerals, Soil, Rocks, Flora & Fauna',
      icon: Globe2,
      color: 'from-purple-500 to-pink-500',
      path: '/subjects/geography',
    },
  ];

  const features = [
    {
      title: 'AI-Powered Teacher',
      description: 'Customize your own AI teacher with Indian attire and cultural context',
      icon: Brain,
    },
    {
      title: 'Multi-Language Support',
      description: 'Learn in Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi, or English',
      icon: Globe2,
    },
    {
      title: 'Progress Tracking',
      description: 'Track your learning journey with detailed analytics and insights',
      icon: TrendingUp,
    },
    {
      title: 'Achievements & Badges',
      description: 'Earn badges and rewards as you complete lessons and tests',
      icon: Award,
    },
  ];

  return (
    <div className="min-h-screen">
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-primary/5 to-secondary/5 py-20 xl:py-32">
        <div className="absolute inset-0 bg-grid-pattern opacity-5" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-pulse-slow" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto animate-fade-in">
            <h1 className="text-4xl xl:text-6xl font-bold mb-6 animate-float">
              <span className="gradient-text">{t('welcome')}</span>
            </h1>
            <p className="text-lg xl:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              {t('welcomeMessage')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="shadow-elegant hover:shadow-glow transition-smooth">
                <Link to="/subjects">{t('getStarted')}</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="hover:scale-105 transition-smooth">
                <Link to="/teacher">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Create AI Teacher
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 xl:py-24 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl xl:text-4xl font-bold mb-4">{t('subjects')}</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Explore our comprehensive curriculum designed for Indian students
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            {subjects.map((subject, index) => (
              <Link key={subject.path} to={subject.path}>
                <Card 
                  className="h-full transition-smooth hover:shadow-elegant hover:scale-105 cursor-pointer group animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${subject.color} flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-smooth shadow-lg`}>
                      <subject.icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="group-hover:text-primary transition-smooth">{subject.title}</CardTitle>
                    <CardDescription>{subject.description}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 xl:py-24 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl xl:text-4xl font-bold mb-4">Why Choose Shiksha AI?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Experience the future of education with AI-powered personalized learning
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={feature.title} 
                className="text-center hover:shadow-elegant transition-smooth hover:scale-105 animate-scale-in"
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                <CardHeader>
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary-glow flex items-center justify-center mx-auto mb-4 shadow-lg hover:shadow-glow transition-smooth">
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 xl:py-24 bg-gradient-to-br from-primary/10 to-secondary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl xl:text-4xl font-bold mb-6">Ready to Start Learning?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of students already learning with Shiksha AI
          </p>
          <Button asChild size="lg" className="shadow-elegant">
            <Link to="/subjects">{t('getStarted')}</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
