import { useEffect, useState } from 'react';
import { TrendingUp, Clock, Award, Target, BookOpen, Flame } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { useStudent } from '@/contexts/StudentContext';
import { db } from '@/db/api';
import type { LearningProgress, TestResult, Achievement } from '@/types';

export default function Dashboard() {
  const { t } = useLanguage();
  const { studentId } = useStudent();
  const [progress, setProgress] = useState<LearningProgress[]>([]);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (studentId) {
      loadDashboardData();
    }
  }, [studentId]);

  const loadDashboardData = async () => {
    try {
      const [progressData, testsData, achievementsData] = await Promise.all([
        db.learningProgress.getByStudentId(studentId),
        db.testResults.getByStudentId(studentId),
        db.achievements.getByStudentId(studentId),
      ]);

      setProgress(Array.isArray(progressData) ? progressData : []);
      setTestResults(Array.isArray(testsData) ? testsData : []);
      setAchievements(Array.isArray(achievementsData) ? achievementsData : []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalTimeSpent = progress.reduce((sum, p) => sum + (p.time_spent_minutes || 0), 0);
  const completedTopics = progress.filter((p) => p.completed).length;
  const averageScore = testResults.length > 0
    ? Math.round(testResults.reduce((sum, t) => sum + (t.score / t.total_questions) * 100, 0) / testResults.length)
    : 0;

  const subjectProgress = progress.reduce((acc, p) => {
    if (!acc[p.subject]) {
      acc[p.subject] = { total: 0, completed: 0 };
    }
    acc[p.subject].total++;
    if (p.completed) acc[p.subject].completed++;
    return acc;
  }, {} as Record<string, { total: number; completed: number }>);

  const stats = [
    {
      title: t('completedTopics'),
      value: completedTopics,
      icon: BookOpen,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: t('timeSpent'),
      value: `${Math.floor(totalTimeSpent / 60)}h ${totalTimeSpent % 60}m`,
      icon: Clock,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
    },
    {
      title: t('testScores'),
      value: `${averageScore}%`,
      icon: TrendingUp,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
    },
    {
      title: t('achievements'),
      value: achievements.length,
      icon: Award,
      color: 'text-amber-500',
      bgColor: 'bg-amber-500/10',
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
          <p className="text-muted-foreground">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">{t('myProgress')}</h1>
          <p className="text-lg text-muted-foreground">Track your learning journey and achievements</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                Subject Progress
              </CardTitle>
              <CardDescription>Your completion rate across all subjects</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(subjectProgress).map(([subject, data]) => {
                const percentage = Math.round((data.completed / data.total) * 100);
                return (
                  <div key={subject}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium capitalize">{subject}</span>
                      <span className="text-sm text-muted-foreground">
                        {data.completed}/{data.total} topics
                      </span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                );
              })}
              {Object.keys(subjectProgress).length === 0 && (
                <p className="text-center text-muted-foreground py-8">
                  Start learning to see your progress here
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                Recent Achievements
              </CardTitle>
              <CardDescription>Badges and milestones you've earned</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {achievements.slice(0, 5).map((achievement) => (
                  <div key={achievement.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Award className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{achievement.badge_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(achievement.earned_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
                {achievements.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    Complete lessons to earn achievements
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Recent Test Results
            </CardTitle>
            <CardDescription>Your performance in recent tests</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {testResults.slice(0, 5).map((test) => {
                const percentage = Math.round((test.score / test.total_questions) * 100);
                return (
                  <div key={test.id} className="flex items-center justify-between p-3 rounded-lg bg-muted">
                    <div className="flex-1">
                      <p className="font-medium capitalize">{test.subject} - {test.topic}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(test.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">
                        {test.score}/{test.total_questions}
                      </span>
                      <Badge variant={percentage >= 70 ? 'default' : 'secondary'}>
                        {percentage}%
                      </Badge>
                    </div>
                  </div>
                );
              })}
              {testResults.length === 0 && (
                <p className="text-center text-muted-foreground py-8">
                  Take tests to see your results here
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
