import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Volume2, VolumeX, Download, CheckCircle2, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { useStudent } from '@/contexts/StudentContext';
import { ttsService } from '@/services/tts';
import { db } from '@/db/api';
import { toast } from 'sonner';

const sampleContent: Record<string, Record<string, { title: string; content: string; duration: number }>> = {
  mathematics: {
    algebra: {
      title: 'Algebra Fundamentals',
      content: `# Introduction to Algebra

Algebra is a branch of mathematics that uses symbols and letters to represent numbers and quantities in formulas and equations.

## Key Concepts

### Variables
Variables are symbols (usually letters) that represent unknown or changing values. For example, in the equation x + 5 = 10, x is a variable.

### Expressions
An algebraic expression is a combination of variables, numbers, and operations. For example: 3x + 2y - 5

### Equations
An equation is a mathematical statement that two expressions are equal. For example: 2x + 3 = 11

## Solving Linear Equations

To solve a linear equation:
1. Simplify both sides of the equation
2. Isolate the variable on one side
3. Perform the same operation on both sides
4. Check your solution

### Example
Solve: 2x + 5 = 13

Step 1: Subtract 5 from both sides
2x = 8

Step 2: Divide both sides by 2
x = 4

## Practice Problems

1. Solve: 3x - 7 = 14
2. Solve: 5(x + 2) = 25
3. Simplify: 4x + 3x - 2x`,
      duration: 30,
    },
  },
  physics: {
    optics: {
      title: 'Optics - The Study of Light',
      content: `# Optics

Optics is the branch of physics that studies the behavior and properties of light.

## Nature of Light

Light exhibits both wave and particle properties (wave-particle duality).

### Speed of Light
The speed of light in vacuum is approximately 3 × 10⁸ m/s.

## Reflection

Reflection occurs when light bounces off a surface.

### Laws of Reflection
1. The incident ray, reflected ray, and normal all lie in the same plane
2. The angle of incidence equals the angle of reflection

## Refraction

Refraction is the bending of light as it passes from one medium to another.

### Snell's Law
n₁ sin θ₁ = n₂ sin θ₂

Where:
- n₁, n₂ are refractive indices
- θ₁, θ₂ are angles of incidence and refraction

## Lenses

### Convex Lens
- Converges light rays
- Forms real and virtual images
- Used in cameras, telescopes

### Concave Lens
- Diverges light rays
- Forms virtual images
- Used in eyeglasses for myopia`,
      duration: 45,
    },
  },
  history: {
    ramayana: {
      title: 'The Ramayana',
      content: `# The Ramayana

The Ramayana is one of the two major Sanskrit epics of ancient India, composed by sage Valmiki.

## Composition and Significance

- **Date**: 7th–5th centuries BCE to 3rd century CE
- **Structure**: 24,000 shlokas divided into seven kāṇḍas
- **Theme**: Treatise on Dharma, triumph of good over evil

## The Story

### Birth and Marriage
Prince Rama, born to King Dasharatha of Ayodhya, wins Princess Sita's hand by stringing the divine bow of Shiva.

### Exile
Due to a promise made by his father, Rama is exiled to the forest for 14 years. He is accompanied by his devoted wife Sita and loyal brother Lakshmana.

### Abduction of Sita
The demon king Ravana, ruler of Lanka, abducts Sita using a golden deer as a decoy.

### The Quest
Rama forms an alliance with Hanuman and the monkey king Sugriva. Together, they build a bridge to Lanka.

### The Battle
After a fierce battle, Rama defeats Ravana and rescues Sita.

### Return to Ayodhya
Rama returns to Ayodhya and is crowned king, establishing a reign of peace and prosperity.

## Cultural Impact

The Ramayana has profoundly influenced Indian culture, literature, art, and religion for thousands of years.`,
      duration: 40,
    },
  },
  geography: {
    minerals: {
      title: 'Minerals and Their Distribution',
      content: `# Minerals

Minerals are naturally occurring inorganic substances with a definite chemical composition and physical properties.

## Types of Minerals

### Metallic Minerals
- **Iron Ore**: Found in Jharkhand, Odisha, Chhattisgarh
- **Bauxite**: Found in Odisha, Gujarat, Jharkhand
- **Copper**: Found in Rajasthan, Jharkhand
- **Gold**: Found in Karnataka, Andhra Pradesh

### Non-Metallic Minerals
- **Limestone**: Used in cement industry
- **Mica**: Found in Jharkhand, Andhra Pradesh
- **Gypsum**: Used in plaster of Paris

### Energy Minerals
- **Coal**: Found in Jharkhand, Odisha, Chhattisgarh
- **Petroleum**: Found in Mumbai High, Gujarat
- **Natural Gas**: Found in Krishna-Godavari basin

## Mining Processes

### Surface Mining
Used when minerals are close to the surface.

### Underground Mining
Used when minerals are deep below the surface.

## Economic Importance

Minerals are essential for:
- Industrial development
- Energy production
- Construction
- Manufacturing
- Export and trade

## Conservation

Minerals are non-renewable resources and must be used sustainably.`,
      duration: 35,
    },
  },
};

export default function Learn() {
  const { subject, topic } = useParams<{ subject: string; topic: string }>();
  const { t, contentLanguage } = useLanguage();
  const { studentId } = useStudent();
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speed, setSpeed] = useState([1.0]);
  const [progress, setProgress] = useState(0);
  const [startTime] = useState(Date.now());

  const content = subject && topic ? sampleContent[subject]?.[topic] : null;

  useEffect(() => {
    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      if (content) {
        const percentage = Math.min((elapsed / (content.duration * 60)) * 100, 100);
        setProgress(percentage);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [startTime, content]);

  const handleSpeak = () => {
    if (isSpeaking) {
      ttsService.stop();
      setIsSpeaking(false);
    } else if (content) {
      ttsService.speak(content.content, contentLanguage, speed[0]);
      setIsSpeaking(true);
    }
  };

  const handleComplete = async () => {
    if (!studentId || !subject || !topic) return;

    try {
      const elapsed = Math.floor((Date.now() - startTime) / 60000);
      await db.learningProgress.upsert({
        student_id: studentId,
        subject,
        topic,
        completed: true,
        time_spent_minutes: elapsed,
        last_accessed: new Date().toISOString(),
      });

      toast.success('Topic marked as complete!');
    } catch (error) {
      console.error('Error marking complete:', error);
      toast.error('Failed to save progress');
    }
  };

  const handleDownloadNotes = () => {
    if (!content) return;

    const blob = new Blob([content.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${content.title}.md`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Notes downloaded successfully');
  };

  if (!content) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Content Not Found</CardTitle>
            <CardDescription>The requested topic could not be found.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link to="/subjects">Back to Subjects</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        <div className="mb-6">
          <Button asChild variant="ghost" size="sm">
            <Link to="/subjects">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Subjects
            </Link>
          </Button>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-3xl mb-2">{content.title}</CardTitle>
                <CardDescription className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  <span className="capitalize">{subject}</span>
                  <span>•</span>
                  <span>{content.duration} min read</span>
                </CardDescription>
              </div>
              <Badge variant="secondary">{Math.round(progress)}% Complete</Badge>
            </div>
            <Progress value={progress} className="mt-4" />
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          <div className="xl:col-span-3">
            <Card>
              <CardContent className="pt-6">
                <div className="prose prose-slate dark:prose-invert max-w-none">
                  {content.content.split('\n').map((line, index) => {
                    if (line.startsWith('# ')) {
                      return <h1 key={index} className="text-3xl font-bold mb-4">{line.slice(2)}</h1>;
                    }
                    if (line.startsWith('## ')) {
                      return <h2 key={index} className="text-2xl font-bold mt-6 mb-3">{line.slice(3)}</h2>;
                    }
                    if (line.startsWith('### ')) {
                      return <h3 key={index} className="text-xl font-semibold mt-4 mb-2">{line.slice(4)}</h3>;
                    }
                    if (line.trim() === '') {
                      return <br key={index} />;
                    }
                    return <p key={index} className="mb-2">{line}</p>;
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="xl:col-span-1">
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg">Learning Tools</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Button
                    onClick={handleSpeak}
                    variant={isSpeaking ? 'destructive' : 'default'}
                    className="w-full"
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="h-4 w-4 mr-2" />
                        {t('stop')}
                      </>
                    ) : (
                      <>
                        <Volume2 className="h-4 w-4 mr-2" />
                        {t('listen')}
                      </>
                    )}
                  </Button>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    {t('speed')}: {speed[0]}x
                  </label>
                  <Slider
                    value={speed}
                    onValueChange={setSpeed}
                    min={0.5}
                    max={2}
                    step={0.25}
                    className="w-full"
                  />
                </div>

                <Button onClick={handleDownloadNotes} variant="outline" className="w-full">
                  <Download className="h-4 w-4 mr-2" />
                  {t('downloadNotes')}
                </Button>

                <Button onClick={handleComplete} variant="secondary" className="w-full">
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Mark Complete
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
