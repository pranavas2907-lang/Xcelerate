import { useState, useCallback } from 'react';
import { Upload, Loader2, Save, Sparkles } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useLanguage } from '@/contexts/LanguageContext';
import { useStudent } from '@/contexts/StudentContext';
import { generateTeacherAvatar } from '@/services/imageGeneration';
import { supabase } from '@/db/supabase';
import { db } from '@/db/api';
import { toast } from 'sonner';
import { useDropzone } from 'react-dropzone';

const attireOptions = [
  { value: 'saree', label: 'Saree (Traditional)', description: 'Elegant traditional Indian saree' },
  { value: 'kurta', label: 'Kurta Pajama', description: 'Comfortable traditional attire' },
  { value: 'sherwani', label: 'Sherwani', description: 'Formal traditional wear' },
  { value: 'salwar', label: 'Salwar Kameez', description: 'Classic Indian outfit' },
  { value: 'dhoti', label: 'Dhoti Shirt', description: 'Traditional dhoti with shirt' },
];

const backgroundOptions = [
  { value: 'classroom', label: 'Classroom', description: 'Traditional Indian classroom setting' },
  { value: 'library', label: 'Library', description: 'Peaceful library with books' },
  { value: 'auditorium', label: 'Auditorium', description: 'Open hall with stage' },
  { value: 'garden', label: 'Garden', description: 'Outdoor garden setting' },
];

const accessoryOptions = [
  { value: 'glasses', label: 'Eyeglasses' },
  { value: 'bindi', label: 'Bindi' },
  { value: 'turban', label: 'Turban' },
  { value: 'shawl', label: 'Shawl' },
  { value: 'pointer', label: 'Pointer Stick' },
];

export default function TeacherCustomization() {
  const { t } = useLanguage();
  const { studentId } = useStudent();
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [generatedAvatar, setGeneratedAvatar] = useState<string | null>(null);
  const [teacherName, setTeacherName] = useState('');
  const [attire, setAttire] = useState('saree');
  const [background, setBackground] = useState('classroom');
  const [accessories, setAccessories] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const compressImage = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          const maxSize = 1080;
          if (width > height && width > maxSize) {
            height = (height * maxSize) / width;
            width = maxSize;
          } else if (height > maxSize) {
            width = (width * maxSize) / height;
            height = maxSize;
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);

          canvas.toBlob(
            (blob) => {
              if (blob && blob.size <= 1024 * 1024) {
                const reader2 = new FileReader();
                reader2.onloadend = () => resolve(reader2.result as string);
                reader2.readAsDataURL(blob);
              } else {
                canvas.toBlob(
                  (blob2) => {
                    if (blob2) {
                      const reader3 = new FileReader();
                      reader3.onloadend = () => resolve(reader3.result as string);
                      reader3.readAsDataURL(blob2);
                    } else {
                      reject(new Error('Compression failed'));
                    }
                  },
                  'image/webp',
                  0.6
                );
              }
            },
            'image/webp',
            0.8
          );
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error('File size must be less than 10MB');
      return;
    }

    if (!file.type.match(/^image\/(jpeg|png|webp)$/)) {
      toast.error('Only JPG, PNG, and WEBP images are supported');
      return;
    }

    try {
      const compressed = await compressImage(file);
      setUploadedImage(compressed);
      toast.success('Image uploaded successfully');
    } catch (error) {
      console.error('Image compression error:', error);
      toast.error('Failed to process image');
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/webp': ['.webp'],
    },
    maxFiles: 1,
    multiple: false,
  });

  const handleGenerateAvatar = async () => {
    if (!uploadedImage) {
      toast.error('Please upload a photo first');
      return;
    }

    setIsGenerating(true);
    try {
      const attireDesc = attireOptions.find((a) => a.value === attire)?.description || attire;
      const bgDesc = backgroundOptions.find((b) => b.value === background)?.description || background;
      const accessoryList = accessories.map((a) => accessoryOptions.find((opt) => opt.value === a)?.label || a);

      const avatarUrl = await generateTeacherAvatar(uploadedImage, attireDesc, bgDesc, accessoryList);
      setGeneratedAvatar(avatarUrl);
      toast.success('AI teacher avatar generated successfully!');
    } catch (error) {
      console.error('Avatar generation error:', error);
      toast.error('Failed to generate avatar. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveTeacher = async () => {
    if (!generatedAvatar || !teacherName.trim()) {
      toast.error('Please generate an avatar and enter a teacher name');
      return;
    }

    setIsSaving(true);
    try {
      const fileName = `teacher_${studentId}_${Date.now()}.png`;
      const base64Data = generatedAvatar.split(',')[1];
      const blob = await fetch(generatedAvatar).then((r) => r.blob());

      const { error: uploadError } = await supabase.storage
        .from('app-7pqa63nmb1tt_teacher_avatars_images')
        .upload(fileName, blob, {
          contentType: 'image/png',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('app-7pqa63nmb1tt_teacher_avatars_images')
        .getPublicUrl(fileName);

      await db.teacherAvatars.create({
        student_id: studentId,
        name: teacherName,
        image_url: urlData.publicUrl,
        attire_style: attire,
        background_type: background,
        accessories: { items: accessories },
        is_active: false,
      });

      toast.success('Teacher avatar saved successfully!');
      setTeacherName('');
      setUploadedImage(null);
      setGeneratedAvatar(null);
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save teacher avatar');
    } finally {
      setIsSaving(false);
    }
  };

  const toggleAccessory = (accessory: string) => {
    setAccessories((prev) =>
      prev.includes(accessory) ? prev.filter((a) => a !== accessory) : [...prev, accessory]
    );
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">{t('customizeTeacher')}</h1>
          <p className="text-lg text-muted-foreground">
            Create your personalized AI teacher with your photo and preferences
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5 text-primary" />
                  {t('uploadPhoto')}
                </CardTitle>
                <CardDescription>Upload a clear photo of your face (JPG, PNG, WEBP, max 10MB)</CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-smooth ${
                    isDragActive
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary hover:bg-muted'
                  }`}
                >
                  <input {...getInputProps()} />
                  {uploadedImage ? (
                    <div className="space-y-4">
                      <img
                        src={uploadedImage}
                        alt="Uploaded"
                        className="max-h-64 mx-auto rounded-lg shadow-elegant"
                      />
                      <p className="text-sm text-muted-foreground">Click or drag to replace image</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Upload className="h-12 w-12 mx-auto text-muted-foreground" />
                      <div>
                        <p className="text-lg font-medium">
                          {isDragActive ? 'Drop your photo here' : 'Drag & drop your photo here'}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">or click to browse</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Teacher Details</CardTitle>
                <CardDescription>Customize your AI teacher's appearance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="teacher-name">Teacher Name</Label>
                  <Input
                    id="teacher-name"
                    value={teacherName}
                    onChange={(e) => setTeacherName(e.target.value)}
                    placeholder="e.g., Mrs. Sharma"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="attire">{t('selectAttire')}</Label>
                  <Select value={attire} onValueChange={setAttire}>
                    <SelectTrigger id="attire">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {attireOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div>
                            <div className="font-medium">{option.label}</div>
                            <div className="text-xs text-muted-foreground">{option.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="background">{t('selectBackground')}</Label>
                  <Select value={background} onValueChange={setBackground}>
                    <SelectTrigger id="background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {backgroundOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div>
                            <div className="font-medium">{option.label}</div>
                            <div className="text-xs text-muted-foreground">{option.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Accessories (Optional)</Label>
                  <div className="flex flex-wrap gap-2">
                    {accessoryOptions.map((accessory) => (
                      <Button
                        key={accessory.value}
                        variant={accessories.includes(accessory.value) ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => toggleAccessory(accessory.value)}
                      >
                        {accessory.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleGenerateAvatar}
                  disabled={!uploadedImage || isGenerating}
                  className="w-full"
                  size="lg"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating Avatar...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate AI Teacher
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>Your AI teacher avatar will appear here</CardDescription>
              </CardHeader>
              <CardContent>
                {generatedAvatar ? (
                  <div className="space-y-4">
                    <img
                      src={generatedAvatar}
                      alt="Generated Avatar"
                      className="w-full rounded-lg shadow-elegant"
                    />
                    <Button onClick={handleSaveTeacher} disabled={isSaving} className="w-full" size="lg">
                      {isSaving ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          {t('save')} Teacher
                        </>
                      )}
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-96 bg-muted rounded-lg">
                    <div className="text-center text-muted-foreground">
                      <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Upload a photo and click "Generate AI Teacher"</p>
                      <p className="text-sm mt-2">to see your customized avatar</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tips for Best Results</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p>✓ Use a clear, front-facing photo</p>
                <p>✓ Ensure good lighting</p>
                <p>✓ Face should be clearly visible</p>
                <p>✓ Avoid sunglasses or face coverings</p>
                <p>✓ Image will be compressed to under 1MB automatically</p>
                <p>✓ Generation may take 30-60 seconds</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
