export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface StudentProfile {
  id: string;
  name: string;
  grade?: string;
  avatar_url?: string;
  preferred_ui_language: string;
  preferred_content_language: string;
  created_at: string;
  updated_at: string;
}

export interface TeacherAvatar {
  id: string;
  student_id?: string;
  name: string;
  image_url?: string;
  attire_style?: string;
  background_type?: string;
  accessories?: Record<string, unknown>;
  is_active: boolean;
  created_at: string;
}

export interface LearningProgress {
  id: string;
  student_id: string;
  subject: string;
  topic: string;
  completed: boolean;
  time_spent_minutes: number;
  last_accessed: string;
  created_at: string;
}

export interface TestResult {
  id: string;
  student_id: string;
  subject: string;
  topic: string;
  score: number;
  total_questions: number;
  time_taken_minutes?: number;
  answers?: unknown[];
  created_at: string;
}

export interface StudentGoal {
  id: string;
  student_id: string;
  goal_type: string;
  target_value: number;
  current_value: number;
  completed: boolean;
  created_at: string;
  completed_at?: string;
}

export interface Achievement {
  id: string;
  student_id: string;
  badge_type: string;
  badge_name: string;
  earned_at: string;
}

export type Language = 'en' | 'hi' | 'kn' | 'ta' | 'te' | 'ml' | 'mr';

export type Subject = 'mathematics' | 'physics' | 'chemistry' | 'biology' | 'history' | 'geography';

export interface SubjectTopic {
  id: string;
  title: string;
  description: string;
  content: string;
  duration?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
}
