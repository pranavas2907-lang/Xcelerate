import Home from './pages/Home';
import Subjects from './pages/Subjects';
import Dashboard from './pages/Dashboard';
import Settings from './pages/Settings';
import Learn from './pages/Learn';
import TeacherCustomization from './pages/TeacherCustomization';
import MyTeachers from './pages/MyTeachers';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />,
    visible: false,
  },
  {
    name: 'Subjects',
    path: '/subjects',
    element: <Subjects />,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <Dashboard />,
  },
  {
    name: 'My Teachers',
    path: '/my-teachers',
    element: <MyTeachers />,
  },
  {
    name: 'Create Teacher',
    path: '/teacher',
    element: <TeacherCustomization />,
    visible: false,
  },
  {
    name: 'Settings',
    path: '/settings',
    element: <Settings />,
  },
  {
    name: 'Learn',
    path: '/learn/:subject/:topic',
    element: <Learn />,
    visible: false,
  },
];

export default routes;