# Shiksha AI - User Guide

Welcome to Shiksha AI (शिक्षा AI), your AI-powered learning companion!

## Getting Started

### First Visit
When you first visit Shiksha AI, the platform automatically creates a unique student profile for you. No registration or login is required!

### Choosing Your Language
1. **Interface Language**: Click the globe icon (🌐) in the top-right corner to select your preferred language for menus and buttons
2. **Content Language**: Go to Settings to choose the language for lessons and AI responses

**Supported Languages**: English, Hindi (हिन्दी), Kannada (ಕನ್ನಡ), Tamil (தமிழ்), Telugu (తెలుగు), Malayalam (മലയാളം), Marathi (मराठी)

## Main Features

### 1. Home Page
- **Welcome Section**: Introduction to Shiksha AI
- **Subject Cards**: Quick access to all subjects
- **Feature Highlights**: Learn about AI teacher, multi-language support, and progress tracking

### 2. Subjects
Browse all available subjects and topics:
- **Mathematics**: Algebra, Geometry, Calculus, Trigonometry
- **Physics**: Optics, Laws of Motion, Equilibrium, Modern Physics
- **Chemistry**: Organic, Inorganic, Physical Chemistry
- **Biology**: Cell Biology, Genetics, Ecology
- **History**: Ramayana, Mahabharata, Mughal Empire, Gupta Dynasty
- **Geography**: Minerals, Soil, Rocks, Amazon Flora & Fauna

Click on any topic to start learning!

### 3. Learning Interface

#### Reading Content
- Content is displayed in an easy-to-read format
- Progress bar shows how far you've progressed through the lesson
- Estimated reading time is shown at the top

#### Audio Features
- **Listen Button** (🔊): Hear the lesson read aloud in your chosen language
- **Stop Button** (⏹): Stop the audio playback
- **Speed Control**: Adjust playback speed from 0.5x to 2x
  - 0.5x: Slow (for difficult concepts)
  - 1.0x: Normal speed
  - 1.5x: Fast (for review)
  - 2.0x: Very fast (for quick revision)

#### Learning Tools
- **Download Notes**: Save the lesson as a text file for offline reading
- **Mark Complete**: Track your progress by marking topics as complete

### 4. AI Chatbot

#### Accessing the Chatbot
Look for the pulsing chat icon (💬) in the bottom-right corner of any page.

#### Using the Chatbot
1. Click the chat icon to open
2. Type your question in the input box
3. Press Enter or click Send
4. The AI will respond with helpful explanations
5. Click the "Listen" button on any AI response to hear it spoken

#### What You Can Ask
- **Subject Questions**: "Explain quadratic equations"
- **Clarifications**: "What does refraction mean?"
- **Examples**: "Give me an example of Newton's third law"
- **Study Tips**: "How can I remember the periodic table?"
- **Practice**: "Can you quiz me on algebra?"

The AI chatbot is friendly, patient, and designed specifically for Indian students!

### 5. Dashboard

#### Your Progress
- **Completed Topics**: See how many topics you've finished
- **Time Spent**: Track your total learning time
- **Test Scores**: View your average test performance
- **Achievements**: See badges you've earned

#### Subject Progress
- Visual progress bars for each subject
- Completion percentage
- Topics completed vs. total topics

#### Recent Activity
- Latest test results
- Recently earned achievements
- Learning streaks

### 6. Settings

#### Profile
- **Name**: Enter your name
- **Grade/Class**: Specify your current grade (e.g., "Class 10")

#### Language Preferences
- **Interface Language**: Language for buttons, menus, and navigation
- **Content Language**: Language for lessons, tests, and AI responses

#### Appearance
- **Dark Mode**: Toggle between light and dark themes
  - Dark mode is easier on the eyes for extended reading
  - Light mode is better for bright environments

#### Notifications
- **Learning Reminders**: Get reminded to continue your studies

## Tips for Effective Learning

### 1. Use the AI Chatbot
Don't hesitate to ask questions! The AI is there to help you understand difficult concepts.

### 2. Listen While Reading
Use the audio feature to reinforce learning through multiple senses.

### 3. Adjust Speed
- Use slower speeds for new or difficult topics
- Use faster speeds for review and revision

### 4. Track Your Progress
Regularly check your dashboard to see your improvement and stay motivated.

### 5. Download Notes
Save important lessons for offline study and quick revision.

### 6. Mark Topics Complete
This helps you track what you've learned and what's left to study.

### 7. Choose Your Comfortable Language
Learn in the language you're most comfortable with - you can always switch!

## Keyboard Shortcuts

- **Ctrl + H**: Open AI Chatbot (coming soon)
- **Enter**: Send message in chatbot
- **Esc**: Close chatbot

## Troubleshooting

### Audio Not Working
1. Check your device volume
2. Make sure your browser allows audio
3. Try refreshing the page
4. Check if your browser supports Web Speech API

### Language Not Changing
1. Make sure you've selected the language from the dropdown
2. Refresh the page if needed
3. Check that your browser supports the selected language

### Progress Not Saving
1. Make sure you have internet connection
2. Click "Mark Complete" after finishing a topic
3. Check your browser's local storage settings

### Chatbot Not Responding
1. Check your internet connection
2. Try refreshing the page
3. Make sure you've typed a question
4. Wait a few seconds for the AI to process

## Privacy & Data

### What We Store
- Your learning progress
- Test results
- Language preferences
- Time spent on topics
- Achievements earned

### What We Don't Store
- No personal information required
- No email or phone number
- No login credentials
- No payment information

### Your Data
- All data is stored securely in Supabase
- You can view your data in the Dashboard
- Your student ID is stored locally in your browser

## Support

### Need Help?
- Use the AI Chatbot for learning questions
- Check this User Guide for feature explanations
- Contact support at: support@shiksha-ai.com

### Feedback
We'd love to hear from you! Share your experience and suggestions to help us improve Shiksha AI.

## Best Practices

### For Students
1. **Set a Schedule**: Learn at the same time each day
2. **Start Small**: Begin with easier topics to build confidence
3. **Ask Questions**: Use the AI chatbot whenever you're confused
4. **Review Regularly**: Revisit completed topics to reinforce learning
5. **Track Progress**: Check your dashboard weekly to stay motivated

### For Parents
1. **Monitor Progress**: Check the dashboard to see your child's learning
2. **Encourage Questions**: Remind them to use the AI chatbot
3. **Set Goals**: Help them set realistic learning targets
4. **Celebrate Achievements**: Acknowledge badges and milestones
5. **Provide Support**: Be available to discuss what they're learning

## Frequently Asked Questions

### Q: Do I need to create an account?
**A**: No! Shiksha AI works without any registration. Your progress is automatically saved.

### Q: Can I use Shiksha AI on my phone?
**A**: Yes! The platform is fully responsive and works on all devices.

### Q: Is the content aligned with Indian curriculum?
**A**: Yes! All content is designed specifically for Indian students with cultural context.

### Q: Can I learn in my native language?
**A**: Absolutely! We support 7 Indian languages plus English.

### Q: Is Shiksha AI free?
**A**: Yes! All features are currently available at no cost.

### Q: How does the AI teacher work?
**A**: The AI uses advanced language models to understand your questions and provide helpful, personalized explanations.

### Q: Can I download lessons for offline study?
**A**: Yes! Use the "Download Notes" button to save lessons as text files.

### Q: Will my progress be saved if I close the browser?
**A**: Yes! Your progress is automatically saved to the cloud.

### Q: Can multiple students use the same device?
**A**: Yes, but they'll share the same progress. For separate tracking, use different browsers or devices.

### Q: How accurate is the AI chatbot?
**A**: The AI is trained on educational content and provides accurate information. However, always verify important facts with your textbooks or teachers.

---

**Happy Learning with Shiksha AI! 📚✨**

*Empowering Indian students through AI-powered education*
