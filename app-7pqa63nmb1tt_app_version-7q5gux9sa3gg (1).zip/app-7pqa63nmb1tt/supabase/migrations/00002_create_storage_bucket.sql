/*
# Create Storage Bucket for Teacher Avatar Images

## 1. Storage Bucket
- Bucket name: `app-7pqa63nmb1tt_teacher_avatars_images`
- Public access for reading
- File size limit: 10MB (as per requirements)
- Allowed MIME types: image/jpeg, image/png, image/webp

## 2. Security
- Public read access (anyone can view images)
- Public write access (anyone can upload - no login system)

## 3. Notes
- Used for storing uploaded face images and generated AI teacher avatars
- Automatic compression will be handled on frontend before upload
*/

-- Create storage bucket for teacher avatar images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7pqa63nmb1tt_teacher_avatars_images',
  'app-7pqa63nmb1tt_teacher_avatars_images',
  true,
  10485760,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']
)
ON CONFLICT (id) DO NOTHING;

-- Create policy for public read access
CREATE POLICY "Public read access for teacher avatars"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-7pqa63nmb1tt_teacher_avatars_images');

-- Create policy for public upload access
CREATE POLICY "Public upload access for teacher avatars"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'app-7pqa63nmb1tt_teacher_avatars_images');

-- Create policy for public update access
CREATE POLICY "Public update access for teacher avatars"
ON storage.objects FOR UPDATE
USING (bucket_id = 'app-7pqa63nmb1tt_teacher_avatars_images');

-- Create policy for public delete access
CREATE POLICY "Public delete access for teacher avatars"
ON storage.objects FOR DELETE
USING (bucket_id = 'app-7pqa63nmb1tt_teacher_avatars_images');