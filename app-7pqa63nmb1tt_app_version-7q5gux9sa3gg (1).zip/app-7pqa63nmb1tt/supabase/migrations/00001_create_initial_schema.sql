/*
# Create Initial Schema for Shiksha AI Platform

## 1. New Tables

### `student_profiles`
- `id` (uuid, primary key, references auth.users)
- `name` (text, not null)
- `grade` (text)
- `avatar_url` (text)
- `preferred_ui_language` (text, default: 'en')
- `preferred_content_language` (text, default: 'en')
- `created_at` (timestamptz, default: now())
- `updated_at` (timestamptz, default: now())

### `teacher_avatars`
- `id` (uuid, primary key, default: gen_random_uuid())
- `student_id` (uuid, references student_profiles)
- `name` (text, not null)
- `image_url` (text)
- `attire_style` (text)
- `background_type` (text)
- `accessories` (jsonb)
- `is_active` (boolean, default: false)
- `created_at` (timestamptz, default: now())

### `learning_progress`
- `id` (uuid, primary key, default: gen_random_uuid())
- `student_id` (uuid, references student_profiles)
- `subject` (text, not null)
- `topic` (text, not null)
- `completed` (boolean, default: false)
- `time_spent_minutes` (integer, default: 0)
- `last_accessed` (timestamptz, default: now())
- `created_at` (timestamptz, default: now())

### `test_results`
- `id` (uuid, primary key, default: gen_random_uuid())
- `student_id` (uuid, references student_profiles)
- `subject` (text, not null)
- `topic` (text, not null)
- `score` (integer, not null)
- `total_questions` (integer, not null)
- `time_taken_minutes` (integer)
- `answers` (jsonb)
- `created_at` (timestamptz, default: now())

### `student_goals`
- `id` (uuid, primary key, default: gen_random_uuid())
- `student_id` (uuid, references student_profiles)
- `goal_type` (text, not null)
- `target_value` (integer, not null)
- `current_value` (integer, default: 0)
- `completed` (boolean, default: false)
- `created_at` (timestamptz, default: now())
- `completed_at` (timestamptz)

### `achievements`
- `id` (uuid, primary key, default: gen_random_uuid())
- `student_id` (uuid, references student_profiles)
- `badge_type` (text, not null)
- `badge_name` (text, not null)
- `earned_at` (timestamptz, default: now())

## 2. Security
- All tables are public (no RLS) as per requirements
- No login system required - using anonymous UUID-based tracking
- All users can read and write their own data

## 3. Notes
- Using UUID-based anonymous user tracking
- JSONB for flexible data storage (accessories, answers)
- Timestamps for tracking and analytics
*/

-- Create student_profiles table
CREATE TABLE IF NOT EXISTS student_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  grade text,
  avatar_url text,
  preferred_ui_language text DEFAULT 'en',
  preferred_content_language text DEFAULT 'en',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create teacher_avatars table
CREATE TABLE IF NOT EXISTS teacher_avatars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES student_profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  image_url text,
  attire_style text,
  background_type text,
  accessories jsonb DEFAULT '{}',
  is_active boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create learning_progress table
CREATE TABLE IF NOT EXISTS learning_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES student_profiles(id) ON DELETE CASCADE,
  subject text NOT NULL,
  topic text NOT NULL,
  completed boolean DEFAULT false,
  time_spent_minutes integer DEFAULT 0,
  last_accessed timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, subject, topic)
);

-- Create test_results table
CREATE TABLE IF NOT EXISTS test_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES student_profiles(id) ON DELETE CASCADE,
  subject text NOT NULL,
  topic text NOT NULL,
  score integer NOT NULL,
  total_questions integer NOT NULL,
  time_taken_minutes integer,
  answers jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now()
);

-- Create student_goals table
CREATE TABLE IF NOT EXISTS student_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES student_profiles(id) ON DELETE CASCADE,
  goal_type text NOT NULL,
  target_value integer NOT NULL,
  current_value integer DEFAULT 0,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES student_profiles(id) ON DELETE CASCADE,
  badge_type text NOT NULL,
  badge_name text NOT NULL,
  earned_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_learning_progress_student ON learning_progress(student_id);
CREATE INDEX IF NOT EXISTS idx_test_results_student ON test_results(student_id);
CREATE INDEX IF NOT EXISTS idx_teacher_avatars_student ON teacher_avatars(student_id);
CREATE INDEX IF NOT EXISTS idx_student_goals_student ON student_goals(student_id);
CREATE INDEX IF NOT EXISTS idx_achievements_student ON achievements(student_id);