# Shiksha AI - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Choose Your Language
1. Click the globe icon (🌐) in the top-right corner
2. Select your preferred language from the dropdown
3. The interface will instantly switch to your language

### Step 2: Create Your AI Teacher
1. Click **"Create AI Teacher"** on the home page
2. Upload a clear photo of yourself or anyone you'd like as your teacher
3. Choose traditional Indian attire (Saree, Kurta, Sherwani, etc.)
4. Select a background (Classroom, Library, Auditorium, Garden)
5. Add optional accessories (Glasses, Bindi, Turban, etc.)
6. Click **"Generate AI Teacher"** and wait 30-60 seconds
7. Click **"Save Teacher"** to keep your avatar

### Step 3: Start Learning
1. Go to **"Subjects"** from the navigation menu
2. Choose a subject (Mathematics, Science, History, Geography)
3. Click on any topic to start learning
4. Use the **"Listen"** button (🔊) to hear the lesson
5. Adjust speed with the slider (0.5x - 2x)
6. Download notes for offline study

### Step 4: Ask Questions
1. Click the chat icon (💬) in the bottom-right corner
2. Type your question in any language
3. Get instant AI-powered answers
4. Click "Listen" to hear the response

### Step 5: Track Your Progress
1. Go to **"Dashboard"** to see your statistics
2. View completed topics, time spent, and test scores
3. Check your achievements and badges
4. Set learning goals and track progress

## 🎯 Key Features

### AI Teacher Customization
- **Upload Photo**: Drag & drop or click to browse
- **Auto-Compression**: Images automatically compressed to under 1MB
- **Multiple Teachers**: Create and save multiple AI teacher avatars
- **Manage Teachers**: View, activate, or delete teachers in "My Teachers"

### Multi-Language Support
- **7 Indian Languages**: Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi
- **English**: Full English support
- **Dual Selection**: Separate UI and content language
- **Instant Switching**: Change language anytime without losing progress

### Enhanced Audio
- **Clean Playback**: Special characters automatically removed
- **Speed Control**: 0.5x to 2x playback speed
- **Multi-Language TTS**: Native voice for each language
- **Auto-Speak**: AI responses automatically spoken

### Learning Tools
- **Progress Tracking**: Real-time progress during lessons
- **Download Notes**: Save lessons as text files
- **Mark Complete**: Track completed topics
- **AI Chatbot**: 24/7 learning assistant

## 📱 Navigation

### Main Menu
- **Home**: Welcome page with quick access
- **Subjects**: Browse all subjects and topics
- **Dashboard**: View your progress and statistics
- **My Teachers**: Manage your AI teacher avatars
- **Settings**: Customize preferences and profile

### Quick Actions
- **Language Selector**: Top-right corner (🌐)
- **AI Chatbot**: Bottom-right corner (💬)
- **Create Teacher**: Home page button
- **Start Learning**: Subject cards

## 💡 Tips for Best Results

### Photo Upload
- ✓ Use a clear, front-facing photo
- ✓ Ensure good lighting
- ✓ Face should be clearly visible
- ✓ Avoid sunglasses or face coverings
- ✓ Photos are automatically compressed

### Learning
- ✓ Use slower speeds (0.5x-0.75x) for difficult topics
- ✓ Use faster speeds (1.5x-2x) for review
- ✓ Ask the AI chatbot when confused
- ✓ Download notes for offline study
- ✓ Mark topics complete to track progress

### Language Selection
- ✓ Choose UI language for menus and buttons
- ✓ Choose content language for lessons
- ✓ TTS automatically uses content language
- ✓ Switch languages anytime

## 🔧 Troubleshooting

### Image Upload
**Problem**: File too large  
**Solution**: Use a smaller image or let auto-compression handle it

**Problem**: Upload fails  
**Solution**: Check internet connection and try again

### Audio
**Problem**: No sound  
**Solution**: Check device volume and browser permissions

**Problem**: Wrong language  
**Solution**: Change content language in Settings

### Avatar Generation
**Problem**: Generation fails  
**Solution**: Check internet connection and retry

**Problem**: Slow generation  
**Solution**: Be patient, processing takes 30-60 seconds

## 📚 Sample Learning Path

### For Beginners
1. Start with **Mathematics → Algebra**
2. Use **0.5x speed** for TTS
3. Ask AI chatbot to explain difficult concepts
4. Download notes for review
5. Check dashboard after each lesson

### For Advanced Learners
1. Choose any subject and topic
2. Use **1.5x-2x speed** for quick review
3. Focus on practice problems
4. Track progress in dashboard
5. Set daily learning goals

## 🎓 Learning Best Practices

### Daily Routine
1. **Morning**: Review yesterday's notes (10 min)
2. **Afternoon**: Learn new topic (30 min)
3. **Evening**: Practice with AI chatbot (15 min)
4. **Night**: Check dashboard and set goals (5 min)

### Weekly Goals
- Complete 5-7 topics per week
- Spend 2-3 hours learning
- Ask 10+ questions to AI chatbot
- Download notes for all topics
- Review dashboard every Sunday

### Monthly Milestones
- Complete 1-2 subjects
- Earn 5+ achievement badges
- Maintain 80%+ test scores
- Create 2-3 teacher avatars
- Help others in forums (coming soon)

## 🌟 Advanced Features

### Teacher Management
- Create multiple teachers for different subjects
- Set active teacher for current learning session
- Delete unused teacher avatars
- View teacher details (attire, background, accessories)

### Progress Analytics
- Subject-wise completion rates
- Time spent per topic
- Test performance trends
- Achievement tracking
- Goal progress visualization

### Customization
- Profile settings (name, grade)
- Language preferences (UI and content)
- Theme toggle (dark/light mode)
- Notification preferences
- Audio/video quality settings

## 📞 Support

### Need Help?
- Use the AI Chatbot for learning questions
- Check USER_GUIDE.md for detailed instructions
- Review NEW_FEATURES.md for feature documentation
- Contact support: support@shiksha-ai.com

### Feedback
Share your experience and suggestions to help us improve Shiksha AI!

---

**Happy Learning! 📚✨**

*Shiksha AI - Empowering Indian students through AI-powered education*
